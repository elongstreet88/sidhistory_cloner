// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once
#define SECURITY_WIN32	//to make sspi.h happy

#include <tchar.h>
#include <Windows.h>
#include <Security.h>
#include <Ntdsapi.h>
#include <vcclr.h>